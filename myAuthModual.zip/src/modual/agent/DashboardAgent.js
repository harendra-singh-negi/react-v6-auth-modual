import React from 'react'

export default function DashboardAgent() {
  return (
    <div>DashboardAgent</div>
  )
}
