import React from 'react'

export default function DashboardManager() {
  return (
    <div>DashboardManager</div>
  )
}
