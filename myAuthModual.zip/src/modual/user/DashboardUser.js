import React from 'react'

export default function DashboardUser() {
  return (
    <div>DashboardUser</div>
  )
}
